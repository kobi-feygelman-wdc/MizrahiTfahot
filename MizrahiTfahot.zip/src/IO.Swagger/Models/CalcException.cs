﻿using System;

namespace IO.Swagger.Models
{
    public class CalcException : Exception
    {
        public CalcException(string msg) : base(msg)
        {
        }
    }
}
